#ifndef MATADATA_H
#define MATADATA_H

#include <string>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

struct matadata {
    string cid;
    Mat BGR_frame;
    string object_Detection_result;
    bool object_Detection_result_state = false;

    vector<uchar> encoded_buffer;
    bool encoded_state = false;
};
#endif // MATADATA_H
