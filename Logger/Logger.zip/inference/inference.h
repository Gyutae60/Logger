#ifndef INFERENCE_H
#define INFERENCE_H

#include <iostream>
#include <ctime>
#include <vector>
#include <string>
#include <queue>
#include "../config/Config.h"
#include "../matadata/matadata.h"
#include <curl/curl.h>
#include <opencv2/opencv.hpp>
#include <fstream>
#include <jsoncpp/json/json.h>


class Inference {
public:
    Inference(const Config_cls& config);
    void send_request(std::queue<matadata>& matadata_queue);

private:
    std::string m_server_ip_;
    int m_server_port_;
    std::string m_image_path_;
};

#endif
