#ifndef CONFIG_H
#define CONFIG_H

#include <string>
using namespace std;

class Config_cls {
private:
    int width;
    int height;
    int fps;
    int frameCount;
    string orifilePath;
    string objectDetectorIp;
    int objectDetectorPort;

public:
    Config_cls();  
    ~Config_cls();  

    void Read_Logger_cfg(); 

    int getWidth() const;
    int getHeight() const;
    int getFps() const;
    int getFrameCount() const;
    string getOrifilePath() const;
    string getObjectDetectorIp() const;
    int getObjectDetectorPort() const;
};

#endif // CONFIG_H
