#include "Config.h"
#include <iostream>
#include <fstream>
#include <jsoncpp/json/json.h>
using namespace std;

Config_cls::Config_cls() {
    Read_Logger_cfg(); 
}

Config_cls::~Config_cls() {
    
}

void Config_cls::Read_Logger_cfg() {
    string configPath = "../config.json"; 

    ifstream json_dir(configPath);
    if (!json_dir.is_open()) {
        cerr << "Could not open configuration file" << endl;
        exit(-1);
    }

    Json::CharReaderBuilder builder;
    builder["collectComments"] = false;
    Json::Value value;
    JSONCPP_STRING errs;

    bool ok = Json::parseFromStream(builder, json_dir, &value, &errs);
    if (!ok) {
        cerr << "Failed to parse configuration: " << errs << endl;
        exit(-1);
    }

    width = value["Logger"]["width"].asInt();
    height = value["Logger"]["height"].asInt();
    fps = value["Logger"]["fps"].asInt();
    frameCount = value["Logger"]["frame count"].asInt();
    orifilePath = value["Logger"]["original file path"].asString();
    objectDetectorIp = value["Logger"]["Object Detector Server IP addr"].asString();
    objectDetectorPort = value["Logger"]["Object Detector Server port"].asInt();
}

int Config_cls::getWidth() const { return width; }
int Config_cls::getHeight() const { return height; }
int Config_cls::getFps() const { return fps; }
int Config_cls::getFrameCount() const { return frameCount; }
string Config_cls::getOrifilePath() const { return orifilePath; }
string Config_cls::getObjectDetectorIp() const { return objectDetectorIp; }
int Config_cls::getObjectDetectorPort() const { return objectDetectorPort; }
