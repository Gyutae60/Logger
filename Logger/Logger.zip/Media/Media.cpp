#include "Media.h"

Media_cls::Media_cls(const Config_cls& config) {
    width = config.getWidth();
    height = config.getHeight();
    fps = config.getFps();
    frame_count = config.getFrameCount();
    orifile_path = config.getOrifilePath();
    open_camera();
    lamping_time();
}

Media_cls::~Media_cls() {}

void Media_cls::open_camera() {
    int deviceID = 0;
    int apiID = CAP_V4L2;
    cap.open(deviceID, apiID);

    if (!cap.isOpened()) {
        cerr << "camera doesn't open" << endl;
        exit(0);
    }
}

void Media_cls::lamping_time() {        //초기 프레임 버리기
    Mat temp;
    if (!cap.isOpened()) {
        cerr << "ERROR! Unable to open camera -- lamping time\n";
    }
    for (int i = 0; i < 20; i++) {
        cap >> temp;
    }
    temp.release();
}

int Media_cls::set_frame() {
    if (!cap.isOpened()) {
        cerr << "ERROR! Unable to open camera\n";
        return -1;
    }

    cap.set(cv::CAP_PROP_FOURCC, cv::VideoWriter::fourcc('M', 'J', 'P', 'G'));  //코덱 설정 : Motion JPEG
    cap.set(CAP_PROP_FRAME_WIDTH, width);
    cap.set(CAP_PROP_FRAME_HEIGHT, height);
    cap.set(CAP_PROP_FPS, fps);

    cout << "    Frame Width: " << cvRound(cap.get(CAP_PROP_FRAME_WIDTH)) << endl;
    cout << "    Frame Height: " << cvRound(cap.get(CAP_PROP_FRAME_HEIGHT)) << endl;
    cout << "    FPS : " << cvRound(cap.get(CAP_PROP_FPS)) << endl;

    Mat img(Size(width, height), CV_8UC3, Scalar(0));       //(크기, BGR, 전체 검정 배경경)
    this->currentFrame = img.clone();                       //= img는 img와 같은 주소를 지정
    img.release();

    return 0;
}

void Media_cls::capture_frame(queue<matadata>& matadata_queue, mutex& matadata_mutex) {
    unsigned int captured_threshold = 100;

    matadata data;
    
    if (matadata_queue.size() > captured_threshold) {
        cout << "Queue exceeds its threshold" << endl;
        spdlog::info("Queue exceeds its threshold");
        this_thread::sleep_for(chrono::milliseconds(800));
        lamping_time();
        continue;
    }

    auto frame_start_time = std::chrono::steady_clock::now();

    cap.read(currentFrame);

    auto frame_end_time = std::chrono::steady_clock::now();
    int duration = std::chrono::duration_cast<std::chrono::milliseconds>(frame_end_time - frame_start_time).count();
    
    // 이미지 인코딩
    vector<uchar> buf;
    vector<int> params = {IMWRITE_JPEG_QUALITY, 90}; // JPEG 품질 설정
    imencode(".jpg", currentFrame, buf, params);
    
    data.cid = getCID();
    data.BGR_frame = currentFrame;        
    data.encoded_buffer = std::move(buf);

    matadata_queue.push(data);

    std::cout << "T0: " << duration << " ms" << std::endl;

    std::this_thread::sleep_for(std::chrono::milliseconds(3));
    data.BGR_frame.release();
}

void Media_cls::image_save(queue<matadata>& matadata_queue) {
    Mat original;
    string m_cid = matadata_queue.front().cid;
    matadata_queue.front().BGR_frame.copyTo(original);
    string img_name = orifile_path + m_cid + ".png";

    imwrite(img_name, original);

    matadata_queue.front().image_save_state = true;

    original.release();
}
