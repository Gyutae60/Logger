#ifndef MEDIA_H
#define MEDIA_H

#include <iostream>
#include <string>
#include <queue>
#include <mutex>
#include <opencv2/opencv.hpp>
#include "../config/Config.h"
#include "../matadata/matadata.h"
#include "create_cid.h"
#include <spdlog/spdlog.h>

using namespace std;
using namespace cv;

class Media_cls {
public:
    Media_cls(const Config_cls& config);
    ~Media_cls();

    void open_camera();
    void lamping_time();
    int set_frame();

    void capture_frame(queue<matadata>& matadata_queue, mutex& matadata_mutex);
    void image_save(queue<matadata>& matadata_queue);

private:
    int width, height, fps, frame_count;
    string orifile_path;
    
    VideoCapture cap;
    Mat currentFrame;
};

#endif
