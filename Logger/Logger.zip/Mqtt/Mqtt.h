#ifndef MQTTCLIENT_H
#define MQTTCLIENT_H

#include <iostream>
#include <nlohmann/json.hpp>
#include <string>
#include "../matadata/matadata.h"
#include "../config/Config.h"
#include <mqtt/async_client.h>

class MQTTClient {
public:
    explicit MQTTClient(const Config_cls& config);

    void publish_result(const matadata& data);
    void disconnect();

private:
    std::string m_topic;
    mqtt::async_client m_client;
};

#endif // MQTTCLIENT_H
